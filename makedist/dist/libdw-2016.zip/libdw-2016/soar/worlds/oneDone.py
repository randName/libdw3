dimensions(8,2)
wall((1,1.5),(1, 2))
wall((1,1.5),(8,1.5))
initialRobotLoc(1, 0.5)
