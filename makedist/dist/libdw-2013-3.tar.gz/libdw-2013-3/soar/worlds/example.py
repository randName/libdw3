dimensions(10,10)
wall((4,0),(4,4))
wall((6,6),(7,7))
wall((2,2),(8,2))

